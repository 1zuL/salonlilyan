<?php

namespace App\Controllers;
use CodeIgniter\API\ResponseTrait;
use App\Models\ModelBooking;

class Booking extends BaseController
{

    protected $BookingModel; 
    use ResponseTrait;  
    
    function __construct()
    {
        $this->BookingModel = new ModelBooking();
    }

    public function insert()
    {
        // Ambil data dari form
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'jam'      => $this->request->getPost('jam'),
            'service'   => $this->request->getPost('service'),
            'kecamatan' => $this->request->getPost('kecamatan'),
            'alamat'    => $this->request->getPost('alamat'),
            'akomodasi' => $this->request->getPost('akomodasi'),
            'status'    => $this->request->getPost('status'),
            'customer_id' => $this->request->getPost('customer_id'),
            'nama_treatment'  => $this->request->getPost('nama_treatment'),
            'created_at'  => $this->request->getPost('created_at'),
            'updated_at' => $this->request->getPost('updated_at')
        ];
    
        // Memeriksa apakah data dengan jam dan tanggal yang sama sudah ada di database
        $existingBooking = $this->BookingModel->checkExistingBooking($data['tanggal'], $data['jam']);
    
        if ($existingBooking) {
            // Jika ditemukan data dengan jam dan tanggal yang sama
            return $this->respond(['data sudah ada'], 400);
        }
    
        // Memasukkan data peminjaman ke database
        if ($this->BookingModel->insert_booking($data)) {
            return $this->respond(['berhasil tambahkan data'], 200);
        } else {
            return $this->respond(['gagal tambahkan data'], 404);
        }
    }
    

    public function get_booking($customer_id)
    {
        $bookings = $this->BookingModel->getRiwayat($customer_id);

        if (!empty($bookings)) {
            return $this->respond($bookings);
        } else {
            return $this->failNotFound('No bookings found for the provided customer_id');
        }
    }
 
    

}
