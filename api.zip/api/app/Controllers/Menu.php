<?php

namespace App\Controllers;
use CodeIgniter\API\ResponseTrait;
use App\Models\ModelMenu;

class Menu extends BaseController
{

    protected $MenuModel;
    use ResponseTrait;
    
    function __construct()
    {
        $this->MenuModel = new ModelMenu();
        
    }

    public function get_menu()
    {
        
        $menu = $this->MenuModel->getMenu();
        return $this->respond($menu);
    }
}