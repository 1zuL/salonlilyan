<?php

namespace App\Controllers;
use CodeIgniter\API\ResponseTrait;
use App\Models\ModelUser;

class login extends BaseController
{

    protected $UserModel;
    use ResponseTrait;
    
    function __construct()
    {
        $this->UserModel = new ModelUser();
        
    }
    

    
public function login()
    {
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
          
        $cek_login = $this->UserModel->cekUseremail($email);
        if ($cek_login->getNumRows() > 0) {
            $akun = $cek_login->getRowArray();
            $pw_valid = $akun['password'];
            if ($password == $pw_valid) {
                return $this->respond(['id' => $akun['id'], 'email' => $akun['email'], 'name' => $akun['name'], 'nomor_hp' => $akun['nomor_hp'] ], 200);
            } else {
                return $this->respond(['message' => 'Invalid username or password'], 401);
            }
        } else {
            return $this->respond(['message' => 'Invalid username or password'], 401);
        }

    }



    public function insert()
    {
        // Ambil data dari form
        $data = [
            'email' => $this->request->getPost('email'),
            'name'      => $this->request->getPost('name'),
            'password'   => $this->request->getPost('password'),
            'nomor_hp' => $this->request->getPost('nomor_hp'),
            
        ];
       
    
        // Memasukkan data peminjaman ke database
        if ($this->UserModel->insert_user($data)) {
            return $this->respond(['berhasil tambahkan data'], 200);
        } else {
            return $this->respond(['gagal tambahkan data'], 404);
        }
    }



    public function reset()
    {
        $email = $this->request->getPost('email');
        $nomor = $this->request->getPost('nomor_hp');
          
        $cek_login = $this->UserModel->cekUseremail($email);
        if ($cek_login->getNumRows() > 0) {
            $akun = $cek_login->getRowArray();
            $pw_valid = $akun['nomor_hp'];
            if ($nomor == $pw_valid) {
                return $this->respond(['id' => $akun['id'], 'email' => $akun['email'], 'name' => $akun['name'], 'nomor_hp' => $akun['nomor_hp'] ], 200);
            } else {
                return $this->respond(['message' => 'Invalid username or password'], 401);
            }
        } else {
            return $this->respond(['message' => 'Invalid username or password'], 401);
        }

    }



public function update($id)
{
    $reset = $this->UserModel->getById($id)->getRow();

    $data = [
        'password' => $this->request->getPost('password'),
        
    ];

    $result = $this->UserModel->update($id, $data);
    if ($result) {
        return $this->respond(['mantap'],200);
    } else {
        return $this->respond(['gagal'],400);
    }
}

    



}
 