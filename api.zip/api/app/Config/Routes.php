<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

//login
$routes->post('login', 'login::login');
$routes->post('register', 'login::insert');
$routes->post('verivikasi_akun', 'login::reset');


//mmenu
$routes->get('menu', 'Menu::get_menu');

//booking
$routes->post('booking', 'Booking::insert');
// $routes->get('riwayat', 'Booking::get_booking');
$routes->get('riwayat/(:num)', 'Booking::get_booking/$1');
$routes->post('reset/(:num)', 'login::update/$1');